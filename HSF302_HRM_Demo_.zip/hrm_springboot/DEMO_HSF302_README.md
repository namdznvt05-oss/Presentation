# HSF302 demo — Persistence Context, Dirty Checking, First-Level Cache

Đã thêm hai file độc lập (không sửa Controller/Service cũ):
- `src/main/java/fu/hr/service/HibernatePresentationDemoService.java`
- `src/main/java/fu/hr/controller/HibernatePresentationDemoController.java`

## Chạy project
1. Mở thư mục `hrm_springboot` trong IntelliJ IDEA (Open -> pom.xml hoặc mở thư mục). Dùng JDK 21 và tải Maven dependencies.
2. Cần SQL Server chạy ở `localhost:1433`, database `HRM_2026`, bảng `departments` có bản ghi thử nghiệm. Cập nhật thông tin kết nối **riêng trên máy của bạn** trong `application.properties` (không chia sẻ mật khẩu).
3. Run `fu.hr.HrmSpringbootApplication`; project dùng port 8080. Dự án có `spring.jpa.show-sql=true`.
4. Mở `http://localhost:8080/departments` để xem ID department có thật trước khi thử.

## Demo 1: L1 Cache + Persistence Context (GET, không sửa DB)
Browser: `http://localhost:8080/presentation-demo/l1/1` (thay 1 bằng ID có thật)
Expected: `a == b = true`. Hai lần `EntityManager.find` trong **cùng transaction** trả cùng object. SQL SELECT có thể không xuất hiện nếu L2 cache được làm nóng từ trước; để chứng minh số SELECT, restart app và thực hiện demo trước các trang khác.

## Demo 2: Dirty Checking (POST, SỬA DB)
Dùng terminal PowerShell:
`Invoke-RestMethod -Method Post -Uri 'http://localhost:8080/presentation-demo/dirty/1' -Body @{ description='Demo HSF302 updated' }`
Thay ID và mô tả; mô tả phải KHÁC giá trị cũ. Console dự kiến có Hibernate UPDATE khi transaction commit, không có `save()` trong code demo.
Kiểm tra lại `/departments`. Dữ liệu thực sự bị thay đổi: chỉ làm trên DB thử nghiệm và khôi phục nếu cần.

## Demo L2 cache có sẵn của project
- `http://localhost:8080/cache-demo`
- `http://localhost:8080/cache-demo/stats`
L2 có Ehcache/JCache trong project. Tuy nhiên demo `findAll` phụ thuộc query cache và vùng cache; không mặc định khẳng định cache hit nếu chưa kiểm tra SQL và thống kê thực tế.

## Khác biệt với slide
- Slide 5 mô tả `DepartmentServiceImpl.update()` đã sửa, nhưng bản project nhận được vẫn có `return null;`. Demo mới dùng một service riêng để minh họa an toàn hơn.
- Slide 15 ví dụ `setName` không khớp project; entity thật là `Department` với `departmentName` và `description`, nên demo dùng `setDescription`.
- Slide 8 cần sửa: L1 cache gắn với Persistence Context/Session, không phải luôn chỉ 1 transaction.

**Tình trạng kiểm thử:** Mã nguồn đã được bổ sung nhưng chưa xác nhận build/run thực tế vì môi trường hiện tại không có Maven dependencies và SQL Server của bạn.


## Trang demo dùng khi thuyết trình với cô (bản tích hợp)

1. Mở `hrm_springboot/pom.xml` trong IntelliJ, sử dụng JDK 21; kết nối SQL Server, đảm bảo có database `HRM_2026` và ít nhất 1 Department.
2. Run `fu.hr.HrmSpringbootApplication`.
3. Truy cập **http://localhost:8080/presentation-demo**.
4. **L1 Cache**: chọn ID, bấm `Chạy L1 Demo`. `a == b = true`, quan sát SELECT trên IntelliJ console.
5. **Dirty Checking**: chọn ID, nhập mô tả MỚI, bấm `Chạy Dirty Checking` (HTTP POST), quan sát UPDATE trên IntelliJ console. Chỉ dùng database thử nghiệm.
6. **L2 Cache**: mở `L2 Cache Demo` và `Cache Statistics`; ghi lại hit/miss thực tế.

### Các file demo bổ sung (không sửa business logic cũ)
- `src/main/java/fu/hr/service/HibernatePresentationDemoService.java`: nghiệp vụ L1 + Dirty Checking.
- `src/main/java/fu/hr/controller/HibernatePresentationDemoController.java`: API L1 GET, Dirty Checking POST.
- `src/main/java/fu/hr/controller/PresentationDemoPageController.java`: trang mở demo.
- `src/main/resources/templates/views/presentation/presentation-demo.html`: giao diện thao tác.

### Lưu ý
- `mvn compile` chỉ xác nhận biên dịch, không thay thế kiểm thử kết nối DB và endpoints.
- Nếu muốn thuyết trình Dirty Checking không có thay đổi, nên nhập description khác giá trị trước đó.
- `spring.jpa.properties.hibernate.hbm2ddl.auto=update` có thể thay đổi schema; nên dùng DB demo riêng trước khi chạy.
