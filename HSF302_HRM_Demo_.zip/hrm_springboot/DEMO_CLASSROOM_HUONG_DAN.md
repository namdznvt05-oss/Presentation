# HSF302 — Classroom Hibernate Demo (giao diện sáng)

## Bắt đầu

1. Mở `hrm_springboot/pom.xml` trong IntelliJ IDEA, dùng JDK 21; Maven Reload.
2. Kiểm tra `src/main/resources/application.properties` phù hợp SQL Server riêng của bạn, database `HRM_2026`. **Không chia sẻ mật khẩu SQL Server khi nộp**.
3. Kiểm tra `src/main/resources/ehcache.xml` tồn tại, chọn Build > Rebuild Project nếu đã gặp lỗi `Couldn't load URI from classpath:ehcache.xml`.
4. Chạy file **main** `src/main/java/fu/hr/HrmSpringbootApplication.java` (không chạy file `HrmSpringbootApplicationTests.java`).
5. Mở **http://localhost:8080/demo** hoặc **http://localhost:8080/presentation-demo**. Ba demo nằm trên một trang.

## Cách thuyết trình

- Demo 1: ID 1 → `Chạy demo 1` → `a == b = true`. Hai lần `find()` trong cùng Persistence Context cùng object. Lần đầu có thể dùng L2 Cache, nên không khẳng định chắc chắn có SELECT.
- Demo 2: Đổi mô tả mới → `Chạy demo 2` → xem `UPDATE departments` trong IntelliJ. Có cập nhật database; dùng cơ sở dữ liệu thử nghiệm. `@Transactional` tự commit khi method thành công; không gọi `save()`.
- Demo 3: ID 1 → `Chạy demo 3` → xem Hits/Misses/Puts. Backend thực hiện hai **giao dịch khác nhau**; lần hai có thể dùng L2 Cache. Demo đặt lại Hibernate statistics và evict một Department ID trước khi đo.

## Các URL

- Dashboard: http://localhost:8080/demo
- Tương thích đường dẫn demo trước: http://localhost:8080/presentation-demo
- Website HRM gốc: http://localhost:8080/departments
- L2 trang gốc: http://localhost:8080/cache-demo
- L2 thống kê gốc: http://localhost:8080/cache-demo/stats

## Files được bổ sung/thay đổi

- ADD `src/main/java/fu/hr/controller/ClassroomDemoController.java`
- ADD `src/main/java/fu/hr/service/ClassroomL2Service.java`
- REPLACE `src/main/resources/templates/views/presentation/presentation-demo.html`
- ADD `DEMO_CLASSROOM_HUONG_DAN.md`

Các file HTML HRM gốc, các Controller/Service/Entity gốc đều giữ nguyên. Những API và trang L2 cũ cũng được giữ để không ảnh hưởng cách demo cũ.

**Lưu ý**: Không có môi trường SQL Server `HRM_2026` trong gói zip nên không thể kiểm thử chạy end-to-end tại đây. Nếu bạn thấy HTTP 404, xác nhận IntelliJ đang chạy đúng project này (không phải bản gốc hay dự án demo cũ), khởi động lại bằng `HrmSpringbootApplication`.
