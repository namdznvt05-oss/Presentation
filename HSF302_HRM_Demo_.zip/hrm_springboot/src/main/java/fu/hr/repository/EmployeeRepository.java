package fu.hr.repository;

import fu.hr.entity.Employees;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.stereotype.Repository;

import jakarta.persistence.QueryHint;
import java.util.List;
import java.util.UUID;

/**
 * EmployeeRepository với Query Cache được bật
 * @QueryHints: Yêu cầu Hibernate cache kết quả query
 * org.hibernate.cacheable = true → Bật query cache
 * org.hibernate.cacheRegion → Chỉ định region cache
 */
@Repository
public interface EmployeeRepository extends JpaRepository<Employees, UUID> {

    /**
     * Override findAll để bật Query Cache
     * Lần 1: Thực hiện SQL → lưu kết quả vào cache
     * Lần 2+: Lấy thẳng từ cache, không chạy SQL
     */
    @QueryHints(value = {
            @QueryHint(name = "org.hibernate.cacheable", value = "true"),
            @QueryHint(name = "org.hibernate.cacheRegion", value = "fu.hr.entity.Employees")
    })
    @Override
    List<Employees> findAll();
}
