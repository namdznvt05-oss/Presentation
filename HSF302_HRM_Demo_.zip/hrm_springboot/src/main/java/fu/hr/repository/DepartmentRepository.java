package fu.hr.repository;

import fu.hr.entity.Department;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import jakarta.persistence.QueryHint;
import java.util.List;

/**
 * DepartmentRepository với Query Cache
 * Các query tìm kiếm department cũng được cache lại
 */
@Repository
public interface DepartmentRepository extends JpaRepository<Department, Long> {

    /**
     * Kiểm tra tồn tại - KHÔNG cache vì cần kết quả thực (tránh false cache)
     */
    boolean existsByDepartmentName(@Param("departmentName") String departmentName);

    /**
     * Tìm kiếm theo tên - BẬT query cache
     * Lần 1: SQL LIKE query → cache kết quả
     * Lần 2 cùng tham số: Lấy từ cache ngay
     */
    @QueryHints(value = {
            @QueryHint(name = "org.hibernate.cacheable", value = "true"),
            @QueryHint(name = "org.hibernate.cacheRegion", value = "fu.hr.entity.Department")
    })
    List<Department> findByDepartmentNameContaining(@Param("departmentName") String departmentName);

    /**
     * Override findAll để bật Query Cache
     */
    @QueryHints(value = {
            @QueryHint(name = "org.hibernate.cacheable", value = "true"),
            @QueryHint(name = "org.hibernate.cacheRegion", value = "fu.hr.entity.Department")
    })
    @Override
    List<Department> findAll();
}
