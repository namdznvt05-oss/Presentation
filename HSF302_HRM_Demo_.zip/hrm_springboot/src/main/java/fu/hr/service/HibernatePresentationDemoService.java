package fu.hr.service;

import fu.hr.entity.Department;
import jakarta.persistence.EntityManager;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Slf4j
public class HibernatePresentationDemoService {

    private final EntityManager entityManager;

    /** Demonstrates identity and the first-level cache within ONE persistence context. */
    @Transactional(readOnly = true)
    public boolean firstLevelCache(Long id) {
        log.info("[L1 DEMO] First find() for Department id={}", id);
        Department a = entityManager.find(Department.class, id);
        if (a == null) {
            throw new IllegalArgumentException("Department not found: " + id);
        }
        log.info("[L1 DEMO] Second find() for same Department id={}", id);
        Department b = entityManager.find(Department.class, id);
        boolean same = a == b;
        log.info("[L1 DEMO] a == b: {} (expected true)", same);
        return same;
    }

    /** Changes a managed entity without calling repository.save() / EntityManager.merge(). */
    @Transactional
    public String dirtyChecking(Long id, String newDescription) {
        Department department = entityManager.find(Department.class, id);
        if (department == null) {
            throw new IllegalArgumentException("Department not found: " + id);
        }
        String oldDescription = department.getDescription();
        if (java.util.Objects.equals(oldDescription, newDescription)) {
            return "Description unchanged; no UPDATE is expected. Try a different value.";
        }
        department.setDescription(newDescription);
        log.info("[DIRTY DEMO] Updated managed Department id={}: '{}' -> '{}'; no save() called", id, oldDescription, newDescription);
        // The transaction interceptor flushes on commit. A SQL UPDATE should appear in logs.
        return "Changed Department id=" + id + " without save(); check Hibernate UPDATE log.";
    }
}
