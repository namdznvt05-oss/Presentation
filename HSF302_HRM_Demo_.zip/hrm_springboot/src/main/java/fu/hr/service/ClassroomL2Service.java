package fu.hr.service;

import fu.hr.entity.Department;
import jakarta.persistence.EntityManager;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class ClassroomL2Service {
    private final EntityManager entityManager;

    // Called by another Spring bean twice; each call gets a distinct transaction/PC.
    @Transactional(readOnly = true)
    public void loadInOwnTransaction(Long id) {
        if (entityManager.find(Department.class, id) == null) {
            throw new IllegalArgumentException("Không tìm thấy Department ID = " + id);
        }
    }
}
