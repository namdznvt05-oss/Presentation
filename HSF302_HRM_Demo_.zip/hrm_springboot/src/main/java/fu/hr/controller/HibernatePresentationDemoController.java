package fu.hr.controller;

import fu.hr.service.HibernatePresentationDemoService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/presentation-demo")
@RequiredArgsConstructor
public class HibernatePresentationDemoController {

    private final HibernatePresentationDemoService demoService;

    @GetMapping("/l1/{id}")
    public String firstLevelCache(@PathVariable Long id) {
        boolean same = demoService.firstLevelCache(id);
        return "First-level cache / Persistence Context: a == b = " + same + ". Check SQL logs.";
    }

    // POST (not GET), since this changes database data.
    @PostMapping("/dirty/{id}")
    public String dirtyChecking(@PathVariable Long id, @RequestParam String description) {
        return demoService.dirtyChecking(id, description);
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<String> handleBadInput(IllegalArgumentException e) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
    }
}
