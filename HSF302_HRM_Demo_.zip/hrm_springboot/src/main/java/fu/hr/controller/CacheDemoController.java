package fu.hr.controller;

import fu.hr.dto.DepartmentResponse;
import fu.hr.dto.EmployeeResponse;
import fu.hr.service.DepartmentService;
import fu.hr.service.EmployeeService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.CacheManager;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.cache.Caching;
import javax.cache.management.CacheStatisticsMXBean;
import javax.management.*;
import java.lang.management.ManagementFactory;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * ============================================================
 * CacheDemoController - Demo L2 Cache Hibernate + Ehcache 3
 * ============================================================
 *
 * Mục đích: Minh họa trực quan sự khác biệt giữa:
 *   - Lần 1 (Cache MISS): SQL được thực thi, kết quả lưu vào L2 Cache
 *   - Lần 2+ (Cache HIT): Không có SQL, lấy thẳng từ RAM → rất nhanh
 *
 * Cách hoạt động:
 *   1. Gọi service → service gọi repository
 *   2. Repository có @QueryHints(cacheable=true)
 *   3. Hibernate kiểm tra L2 Cache trước khi truy vấn DB
 *   4. Nếu MISS → query DB → lưu cache → trả kết quả
 *   5. Nếu HIT → lấy từ cache → trả kết quả (không query DB!)
 * ============================================================
 */
@Controller
@RequestMapping("/cache-demo")
@RequiredArgsConstructor
@Slf4j
public class CacheDemoController {

    private final EmployeeService employeeService;
    private final DepartmentService departmentService;

    /**
     * Trang chính demo L2 Cache
     * Gọi cùng 1 query 2 lần liên tiếp để thấy sự khác biệt
     */
    @GetMapping
    public String cacheDemo(Model model) {

        // ─────────────────────────────────────────────
        // DEMO EMPLOYEES
        // ─────────────────────────────────────────────
        log.info("════════════════════════════════════════════");
        log.info("  CACHE DEMO - EMPLOYEES");
        log.info("════════════════════════════════════════════");

        // --- LẦN 1: Cache MISS (lần đầu gọi sau khi khởi động) ---
        log.info(">>> [LẦN 1] Gọi findAll() Employees - Mong đợi: CACHE MISS → SQL sẽ chạy");
        long start1 = System.nanoTime();
        List<EmployeeResponse> employees = employeeService.findAll();
        long time1 = (System.nanoTime() - start1) / 1_000_000; // đổi sang ms
        log.info(">>> [LẦN 1] Hoàn thành trong {} ms - Xem SQL ở trên ↑", time1);

        // --- LẦN 2: Cache HIT (dữ liệu đã cache từ lần 1) ---
        log.info(">>> [LẦN 2] Gọi findAll() Employees lần 2 - Mong đợi: CACHE HIT → KHÔNG có SQL");
        long start2 = System.nanoTime();
        List<EmployeeResponse> employees2 = employeeService.findAll();
        long time2 = (System.nanoTime() - start2) / 1_000_000;
        log.info(">>> [LẦN 2] Hoàn thành trong {} ms - Kiểm tra: KHÔNG có SQL nào chạy ↑", time2);

        // ─────────────────────────────────────────────
        // DEMO DEPARTMENTS
        // ─────────────────────────────────────────────
        log.info("════════════════════════════════════════════");
        log.info("  CACHE DEMO - DEPARTMENTS");
        log.info("════════════════════════════════════════════");

        log.info(">>> [LẦN 1] Gọi findAll() Departments - Mong đợi: CACHE MISS");
        long dStart1 = System.nanoTime();
        List<DepartmentResponse> departments = departmentService.findAll();
        long dTime1 = (System.nanoTime() - dStart1) / 1_000_000;
        log.info(">>> [LẦN 1] Hoàn thành trong {} ms", dTime1);

        log.info(">>> [LẦN 2] Gọi findAll() Departments lần 2 - Mong đợi: CACHE HIT");
        long dStart2 = System.nanoTime();
        List<DepartmentResponse> departments2 = departmentService.findAll();
        long dTime2 = (System.nanoTime() - dStart2) / 1_000_000;
        log.info(">>> [LẦN 2] Hoàn thành trong {} ms", dTime2);

        log.info("════════════════════════════════════════════");
        log.info("  KẾT QUẢ SO SÁNH:");
        log.info("  Employees - Lần 1 (DB): {} ms | Lần 2 (Cache): {} ms", time1, time2);
        log.info("  Departments - Lần 1 (DB): {} ms | Lần 2 (Cache): {} ms", dTime1, dTime2);
        log.info("════════════════════════════════════════════");

        // ─────────────────────────────────────────────
        // Đưa dữ liệu lên View
        // ─────────────────────────────────────────────
        model.addAttribute("employees", employees);
        model.addAttribute("departments", departments);

        // Kết quả benchmark
        model.addAttribute("empTime1", time1);
        model.addAttribute("empTime2", time2);
        model.addAttribute("deptTime1", dTime1);
        model.addAttribute("deptTime2", dTime2);

        // Tính tốc độ cải thiện
        String empImprovement = time2 == 0 ? "∞ (dưới 1ms)" :
                String.format("%.1fx nhanh hơn", (double) time1 / time2);
        String deptImprovement = dTime2 == 0 ? "∞ (dưới 1ms)" :
                String.format("%.1fx nhanh hơn", (double) dTime1 / dTime2);

        model.addAttribute("empImprovement", empImprovement);
        model.addAttribute("deptImprovement", deptImprovement);

        // Hướng dẫn xem stats
        model.addAttribute("statsUrl", "/actuator/caches");

        return "views/cache/cache-demo";
    }

    /**
     * Xem thống kê cache - Hiển thị hit/miss counts
     * Truy cập: GET /cache-demo/stats
     */
    @GetMapping("/stats")
    public String cacheStats(Model model) {

        // Lấy thống kê JMX từ Ehcache
        Map<String, Map<String, Object>> cacheStats = new HashMap<>();
        String[] cacheNames = {
                "fu.hr.entity.Employees",
                "fu.hr.entity.Department",
                "fu.hr.entity.Jobs"
        };

        MBeanServer mBeanServer = ManagementFactory.getPlatformMBeanServer();

        for (String cacheName : cacheNames) {
            Map<String, Object> stats = new HashMap<>();
            try {
                ObjectName objectName = new ObjectName(
                        "javax.cache:type=CacheStatistics,CacheManager=*,Cache=" + cacheName
                );
                java.util.Set<ObjectName> names = mBeanServer.queryNames(objectName, null);

                if (!names.isEmpty()) {
                    ObjectName found = names.iterator().next();
                    long hits = (Long) mBeanServer.getAttribute(found, "CacheHits");
                    long misses = (Long) mBeanServer.getAttribute(found, "CacheMisses");
                    long gets = (Long) mBeanServer.getAttribute(found, "CacheGets");
                    float hitPercent = (Float) mBeanServer.getAttribute(found, "CacheHitPercentage");

                    stats.put("hits", hits);
                    stats.put("misses", misses);
                    stats.put("gets", gets);
                    stats.put("hitPercent", String.format("%.1f%%", hitPercent));
                } else {
                    stats.put("hits", 0L);
                    stats.put("misses", 0L);
                    stats.put("gets", 0L);
                    stats.put("hitPercent", "0.0% (chưa có dữ liệu - hãy vào /cache-demo trước)");
                }
            } catch (Exception e) {
                stats.put("hits", "N/A");
                stats.put("misses", "N/A");
                stats.put("gets", "N/A");
                stats.put("hitPercent", "Cần bật JMX Statistics trong ehcache.xml");
                log.warn("Không lấy được stats cho cache {}: {}", cacheName, e.getMessage());
            }
            cacheStats.put(cacheName, stats);
        }

        model.addAttribute("cacheStats", cacheStats);
        return "views/cache/cache-stats";
    }
}
