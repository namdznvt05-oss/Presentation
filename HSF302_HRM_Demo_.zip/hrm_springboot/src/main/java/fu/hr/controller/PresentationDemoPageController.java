package fu.hr.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/** Presentation landing page; does not modify data. */
@Controller
public class PresentationDemoPageController {
    @GetMapping("/presentation-demo")
    public String index() {
        return "views/presentation/presentation-demo";
    }
}
