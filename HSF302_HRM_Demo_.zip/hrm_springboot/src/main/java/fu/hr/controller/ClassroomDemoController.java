package fu.hr.controller;

import fu.hr.entity.Department;
import fu.hr.service.ClassroomL2Service;
import fu.hr.service.HibernatePresentationDemoService;
import jakarta.persistence.EntityManagerFactory;
import lombok.RequiredArgsConstructor;
import org.hibernate.SessionFactory;
import org.hibernate.stat.Statistics;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.Map;

@Controller
@RequiredArgsConstructor
public class ClassroomDemoController {
    private final HibernatePresentationDemoService demoService;
    private final ClassroomL2Service l2Service;
    private final EntityManagerFactory emf;

    @GetMapping("/demo")
    public String page() { return "views/presentation/presentation-demo"; }

    @GetMapping("/demo-api/l1/{id}")
    @ResponseBody
    public Map<String, Object> l1(@PathVariable Long id) {
        boolean same = demoService.firstLevelCache(id);
        return Map.of("same", same, "message", "Hai lần find() trả về cùng một Java object trong cùng Persistence Context.");
    }

    @PostMapping("/demo-api/dirty/{id}")
    @ResponseBody
    public Map<String, Object> dirty(@PathVariable Long id, @RequestParam String description) {
        if (description == null || description.isBlank()) throw new IllegalArgumentException("Hãy nhập mô tả mới.");
        String result = demoService.dirtyChecking(id, description.trim());
        return Map.of("message", result, "description", description.trim());
    }

    @GetMapping("/demo-api/l2/{id}")
    @ResponseBody
    public Map<String, Object> l2(@PathVariable Long id) {
        SessionFactory sf = emf.unwrap(SessionFactory.class);
        Statistics stats = sf.getStatistics();
        if (!stats.isStatisticsEnabled()) stats.setStatisticsEnabled(true);
        // Reset only the demo entity entry to make the first read predictable.
        sf.getCache().evictEntityData(Department.class, id);
        stats.clear();
        l2Service.loadInOwnTransaction(id); // first separate Persistence Context
        long firstHits = stats.getSecondLevelCacheHitCount();
        long firstMisses = stats.getSecondLevelCacheMissCount();
        l2Service.loadInOwnTransaction(id); // second separate Persistence Context
        long totalHits = stats.getSecondLevelCacheHitCount();
        long totalMisses = stats.getSecondLevelCacheMissCount();
        Map<String, Object> response = new LinkedHashMap<>();
        response.put("hits", totalHits);
        response.put("misses", totalMisses);
        response.put("puts", stats.getSecondLevelCachePutCount());
        response.put("secondReadHits", totalHits - firstHits);
        response.put("firstReadMisses", firstMisses);
        response.put("note", "Hai giao dịch riêng biệt. Xem thêm SQL Console để kiểm tra lần đọc đầu và lần đọc sau.");
        return response;
    }

    @ExceptionHandler(IllegalArgumentException.class)
    @ResponseBody
    public ResponseEntity<Map<String,String>> badRequest(IllegalArgumentException ex) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of("error", ex.getMessage()));
    }
}
