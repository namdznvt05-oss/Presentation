package fu.hr.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;

/**
 * @Cache: L2 Cache cho Employees
 * READ_WRITE: An toàn khi có cập nhật (update, delete)
 */
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE, region = "fu.hr.entity.Employees")
@Entity
@Table(name = "employees")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Employees {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(name = "first_name", columnDefinition = "NVARCHAR(255)")
    private String firstName;

    @Column(name = "last_name", columnDefinition = "NVARCHAR(255)")
    private String lastName;

    private String email;

    @Column(name = "phone_number")
    private String phoneNumber;

    @Column(name = "hire_date")
    private LocalDate hireDate;

    private BigDecimal salary;

    @Column(name = "commission_pct")
    private Double commissionPct;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "job_id", referencedColumnName = "id")
    private Jobs job;

    @ManyToOne
    @JoinColumn(name = "manager_id", referencedColumnName = "id")
    private Employees manager;

    @OneToOne(mappedBy = "deptManager")
    @JoinColumn(name = "department_id", referencedColumnName = "id")
    private Department department;
}
