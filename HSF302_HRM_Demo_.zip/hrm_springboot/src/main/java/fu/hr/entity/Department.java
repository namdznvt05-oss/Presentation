package fu.hr.entity;

import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * @Cache: Đánh dấu entity này sẽ được lưu vào Hibernate L2 Cache
 * READ_WRITE: Chiến lược đọc-ghi, đảm bảo tính nhất quán khi update
 */
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE, region = "fu.hr.entity.Department")
@Entity
@Table(name = "departments")
@Data
public class Department {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private  Long id;

    @Column(name = "department_name")
    private String departmentName;

    @OneToOne
    @JoinColumn(name = "manager_id", referencedColumnName = "id")
    private Employees deptManager;

    private String description;

}
