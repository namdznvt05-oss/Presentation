package fu.hr.demo;

import fu.hr.entity.Department;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import org.hibernate.SessionFactory;
import org.hibernate.stat.Statistics;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

/**
 * Opt-in classroom demo for slides 12–14. Uses real HRM Department entity.
 * Dirty Checking runs UPDATE + flush, but its transaction is rolled back.
 */
@Component
@ConditionalOnProperty(name = "demo.nam.enabled", havingValue = "true")
public class NamHibernateDemoRunner implements ApplicationRunner {
    private static final Logger log = LoggerFactory.getLogger(NamHibernateDemoRunner.class);

    private final EntityManager entityManager;
    private final SessionFactory sessionFactory;
    private final TransactionTemplate transactionTemplate;
    private final long departmentId;

    public NamHibernateDemoRunner(EntityManager entityManager,
                                  EntityManagerFactory entityManagerFactory,
                                  PlatformTransactionManager transactionManager,
                                  @Value("${demo.nam.department-id:0}") long departmentId) {
        this.entityManager = entityManager;
        this.sessionFactory = entityManagerFactory.unwrap(SessionFactory.class);
        this.transactionTemplate = new TransactionTemplate(transactionManager);
        this.departmentId = departmentId;
    }

    @Override
    public void run(ApplicationArguments args) {
        if (departmentId <= 0) {
            log.warn("[NAM DEMO] Set --demo.nam.department-id to an existing Department ID.");
            return;
        }
        log.info("========== NAM'S HIBERNATE DEMO: Department ID {} ==========", departmentId);
        if (!departmentExists()) {
            log.warn("[NAM DEMO] No Department with ID {}. Demo skipped.", departmentId);
            return;
        }
        demonstrateDirtyChecking();
        demonstrateFirstLevelCache();
        demonstrateSecondLevelCache();
        log.info("========== END OF NAM'S DEMO ==========");
    }

    private boolean departmentExists() {
        return Boolean.TRUE.equals(transactionTemplate.execute(status ->
                entityManager.find(Department.class, departmentId) != null));
    }

    private void demonstrateDirtyChecking() {
        log.info("[DEMO A] DIRTY CHECKING: UPDATE without calling save()");
        transactionTemplate.executeWithoutResult(status -> {
            Department department = entityManager.find(Department.class, departmentId);
            String oldName = department.getDepartmentName();
            String newDescription = "Nam Hibernate demo at " + System.nanoTime();
            log.info("[DEMO A] Changing managed Department.description; name = {}", oldName);
            department.setDescription(newDescription);
            // Hibernate detects a managed entity change and sends SQL UPDATE.
            entityManager.flush();
            log.info("[DEMO A] FLUSH completed; find the UPDATE in SQL logs above.");
            status.setRollbackOnly();
            log.info("[DEMO A] Transaction marked ROLLBACK ONLY; demo change is not committed.");
        });
    }

    private void demonstrateFirstLevelCache() {
        log.info("[DEMO B] FIRST-LEVEL CACHE: two find() calls in one Persistence Context");
        // Ensure the first find() is not satisfied by a pre-existing L2 entry.
        sessionFactory.getCache().evictEntityData(Department.class, departmentId);
        transactionTemplate.executeWithoutResult(status -> {
            Department first = entityManager.find(Department.class, departmentId);
            log.info("[DEMO B] First find() finished. Look for its SELECT.");
            Department second = entityManager.find(Department.class, departmentId);
            log.info("[DEMO B] Second find() finished. No extra SELECT is expected.");
            log.info("[DEMO B] first == second: {}", first == second);
        });
    }

    private void demonstrateSecondLevelCache() {
        log.info("[DEMO C] SECOND-LEVEL CACHE: two separate transactions/contexts");
        Statistics stats = sessionFactory.getStatistics();
        log.info("[DEMO C] L2 enabled: {}; statistics enabled: {}",
                sessionFactory.getSessionFactoryOptions().isSecondLevelCacheEnabled(),
                stats.isStatisticsEnabled());
        if (!sessionFactory.getSessionFactoryOptions().isSecondLevelCacheEnabled()
                || !stats.isStatisticsEnabled()) {
            log.warn("[DEMO C] Enable and verify L2 and statistics before concluding cache hits.");
            return;
        }

        sessionFactory.getCache().evictEntityData(Department.class, departmentId);
        long hitBefore = stats.getSecondLevelCacheHitCount();
        long missBefore = stats.getSecondLevelCacheMissCount();
        long putBefore = stats.getSecondLevelCachePutCount();

        transactionTemplate.executeWithoutResult(status -> {
            entityManager.find(Department.class, departmentId);
            log.info("[DEMO C] Context A: first load done (expect SELECT/cache put).");
        });
        // Transaction A ended: the next execution has a separate transaction-scoped PC.
        transactionTemplate.executeWithoutResult(status -> {
            entityManager.find(Department.class, departmentId);
            log.info("[DEMO C] Context B: second load done (expect L2 hit/no SELECT).");
        });

        log.info("[DEMO C] L2 stats delta: HIT={} MISS={} PUT={}",
                stats.getSecondLevelCacheHitCount() - hitBefore,
                stats.getSecondLevelCacheMissCount() - missBefore,
                stats.getSecondLevelCachePutCount() - putBefore);
        log.info("[DEMO C] Compare this with SQL output. Confirm the provider and entity region are active.");
    }
}
