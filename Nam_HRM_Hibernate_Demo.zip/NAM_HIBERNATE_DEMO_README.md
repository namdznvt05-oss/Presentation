# Hibernate Demo for Nam — HRM Spring Boot

This is an **add-on** to the lecturer's `hrm_springboot` project. It does not modify existing controllers, repositories, or application configuration.

## Installation (IntelliJ IDEA)

1. Open the lecturer's project with JDK 21.
2. Copy `src/main/java/fu/hr/demo/NamHibernateDemoRunner.java` from the add-on into the matching folder in the project.
3. Ensure SQL Server `HRM_2026` is available using the lecturer-provided configuration. Do not publish DB credentials.
4. Find an existing department ID in SQL Server: `SELECT TOP 10 id, department_name FROM departments;`.
5. In IntelliJ: **Run > Edit Configurations > HrmSpringbootApplication > Program arguments**, use:

   ```text
   --demo.nam.enabled=true --demo.nam.department-id=1
   ```

   Replace `1` with an existing Department ID. Run the application and inspect the console for `[DEMO A]`, `[DEMO B]`, `[DEMO C]`.

6. When done, remove the arguments. The add-on is disabled by default.

## Expected behavior — verify against console output

| Demo | Java action | SQL and evidence |
| --- | --- | --- |
| A — Dirty Checking | Load managed Department; change description; `flush()` without `save()` | Expect an `UPDATE`; **transaction rolls back** so change is not committed |
| B — First-level Cache | Two `EntityManager.find()` calls by same ID in one transaction | `first == second` should be `true`; ordinarily just one SELECT for both |
| C — Second-level Cache | Evict the chosen L2 entry, find it in context A, then in context B | Expect an L2 put then hit if Ehcache/JCache works; inspect `HIT/MISS/PUT` deltas and SQL |

The code uses Hibernate's entity-by-ID cache path for demo C, **not** the query cache used by the lecturer's `findAll()` repository methods. Hibernate L1/L2 Entity Cache and Query Cache are distinct.

## Important notes

- The lecturer's project configures Ehcache and L2, but configuration alone does not prove an actual hit.
- SQL Server triggers may have effects outside the rollback boundary. Use a classroom/test database.
- Demo B/C intentionally evict a single Department entry from L2 to make the example repeatable. This temporarily affects cache contents; do not run on production.
- The console SQL may include additional columns in `UPDATE` (Hibernate controls SQL generation).
- `DepartmentServiceImpl.update()` in the supplied project returns `null`; this independent demo does not require it.
- This environment has not executed the Java code against your SQL Server. Do not label expected results as verified until you run them.
- If the existing HRM app fails to start, first check DB access and dependency compatibility. Do not modify the lecturer's cache settings blindly.

## Slide mapping

- **Slide 12:** Spring Boot 4.1.1, Java 21, SQL Server/HRM_2026, Department, planned evidence.
- **Slide 13:** Screenshot `[DEMO A]` and its `UPDATE`; screenshot `[DEMO B]` and `first == second: true`.
- **Slide 14:** Screenshot `[DEMO C]` counters and SQL. If not verified, show it as a test plan and report the limitation.
- **Slide 15:** Summarize Persistence Context, Dirty Checking, L1/L2 scope, limits and Q&A.
