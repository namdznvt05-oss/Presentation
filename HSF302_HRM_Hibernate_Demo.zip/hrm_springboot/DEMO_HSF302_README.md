# HSF302 demo — Persistence Context, Dirty Checking, First-Level Cache

Đã thêm hai file độc lập (không sửa Controller/Service cũ):
- `src/main/java/fu/hr/service/HibernatePresentationDemoService.java`
- `src/main/java/fu/hr/controller/HibernatePresentationDemoController.java`

## Chạy project
1. Mở thư mục `hrm_springboot` trong IntelliJ IDEA (Open -> pom.xml hoặc mở thư mục). Dùng JDK 21 và tải Maven dependencies.
2. Cần SQL Server chạy ở `localhost:1433`, database `HRM_2026`, bảng `departments` có bản ghi thử nghiệm. Cập nhật thông tin kết nối **riêng trên máy của bạn** trong `application.properties` (không chia sẻ mật khẩu).
3. Run `fu.hr.HrmSpringbootApplication`; project dùng port 8080. Dự án có `spring.jpa.show-sql=true`.
4. Mở `http://localhost:8080/departments` để xem ID department có thật trước khi thử.

## Demo 1: L1 Cache + Persistence Context (GET, không sửa DB)
Browser: `http://localhost:8080/presentation-demo/l1/1` (thay 1 bằng ID có thật)
Expected: `a == b = true`. Hai lần `EntityManager.find` trong **cùng transaction** trả cùng object. SQL SELECT có thể không xuất hiện nếu L2 cache được làm nóng từ trước; để chứng minh số SELECT, restart app và thực hiện demo trước các trang khác.

## Demo 2: Dirty Checking (POST, SỬA DB)
Dùng terminal PowerShell:
`Invoke-RestMethod -Method Post -Uri 'http://localhost:8080/presentation-demo/dirty/1' -Body @{ description='Demo HSF302 updated' }`
Thay ID và mô tả; mô tả phải KHÁC giá trị cũ. Console dự kiến có Hibernate UPDATE khi transaction commit, không có `save()` trong code demo.
Kiểm tra lại `/departments`. Dữ liệu thực sự bị thay đổi: chỉ làm trên DB thử nghiệm và khôi phục nếu cần.

## Demo L2 cache có sẵn của project
- `http://localhost:8080/cache-demo`
- `http://localhost:8080/cache-demo/stats`
L2 có Ehcache/JCache trong project. Tuy nhiên demo `findAll` phụ thuộc query cache và vùng cache; không mặc định khẳng định cache hit nếu chưa kiểm tra SQL và thống kê thực tế.

## Khác biệt với slide
- Slide 5 mô tả `DepartmentServiceImpl.update()` đã sửa, nhưng bản project nhận được vẫn có `return null;`. Demo mới dùng một service riêng để minh họa an toàn hơn.
- Slide 15 ví dụ `setName` không khớp project; entity thật là `Department` với `departmentName` và `description`, nên demo dùng `setDescription`.
- Slide 8 cần sửa: L1 cache gắn với Persistence Context/Session, không phải luôn chỉ 1 transaction.

**Tình trạng kiểm thử:** Mã nguồn đã được bổ sung nhưng chưa xác nhận build/run thực tế vì môi trường hiện tại không có Maven dependencies và SQL Server của bạn.
